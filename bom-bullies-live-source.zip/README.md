# BOM Bullies · Bullies of Midgard

Source code for the mobile-first BOM Bullies kennel app.

## Live app

https://c98426f153f671ce2f.v2.appdeploy.ai/

## Included screens

- Home dashboard
- Dog directory
- Puppies and litter center
- Kennel connection form
- Mobile bottom navigation
- Branded launch screen
- Install-app prompt

## Run locally

Requires Node.js 22 and npm.

```bash
npm install
npm run dev
```

## Validate and build

```bash
npm run typecheck
npm run build
```

Production files are generated in `dist/`.

## Project direction

This repository is for the Bomb Bullies / Bullies of Midgard kennel platform. It is not the unrelated Bomberman-style game proposed in old PR #5.

## Next development phase

- Replace monogram placeholders with real dog photography
- Add verified profiles, measurements, pedigree and health records
- Connect inquiries to secure storage and notifications
- Add real litter and puppy records
- Add private owner/admin tools
