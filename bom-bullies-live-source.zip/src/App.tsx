import { FormEvent, useState } from 'react';
import { ArrowRight, Bell, CheckCircle2, ChevronRight, Dog, Download, Heart, Home, Mail, MapPin, MessageCircle, PawPrint, Ruler, Search, ShieldCheck, X } from 'lucide-react';

type Tab = 'home' | 'dogs' | 'puppies' | 'connect';

type DogProfile = {
  name: string;
  subtitle: string;
  status: string;
  details: string[];
  monogram: string;
};

const dogs: DogProfile[] = [
  { name: 'LadiesMan217', subtitle: 'Foundation Stud · True Nano Exotic', status: 'Featured Stud', details: ['8.5–9 inch target class', 'Compact natural structure', 'Kobe legacy influence'], monogram: '217' },
  { name: 'KOBE', subtitle: 'The Nano King Legacy', status: 'Bloodline Archive', details: ['Legacy of kings', 'Production records', 'Pedigree history'], monogram: 'K' },
  { name: 'STEEL', subtitle: 'Pocket American Bully', status: 'Program Profile', details: ['Embark clear', 'ABKC + USBR', 'Champion points'], monogram: 'S' }
];

const tabs: { id: Tab; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'dogs', label: 'Dogs' },
  { id: 'puppies', label: 'Puppies' },
  { id: 'connect', label: 'Connect' }
];

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [installVisible, setInstallVisible] = useState(true);
  const [confirmation, setConfirmation] = useState('');

  const navigate = (tab: Tab) => {
    setActiveTab(tab);
    setConfirmation('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setConfirmation('Inquiry received. The BOM Bullies team will review your message and follow up.');
    event.currentTarget.reset();
  };

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-gray-100">
      <div className="launch-screen" aria-hidden="true">
        <div className="launch-glow" />
        <div className="app-icon launch-icon"><span>B</span></div>
        <div className="mt-7 text-center">
          <p className="text-2xl font-extrabold tracking-[0.13em]"><span className="text-amber-500">BOM</span><span className="mx-1 text-white">💣</span><span className="text-gray-200">BULLIES</span></p>
          <p className="mt-2 text-[10px] uppercase tracking-[0.3em] text-gray-500">Bullies of Midgard</p>
        </div>
        <div className="mt-10 flex gap-2"><span className="loader-dot" /><span className="loader-dot" /><span className="loader-dot" /></div>
      </div>

      <header className="top-nav sticky top-0 z-40 border-b border-gray-800 bg-gray-950/95 backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-6xl items-center justify-between px-4 sm:px-6">
          <button onClick={() => navigate('home')} className="flex items-center gap-3 text-left" aria-label="Open Home">
            <div className="app-icon h-11 w-11 rounded-xl"><span className="text-2xl">B</span></div>
            <div>
              <p className="text-sm font-extrabold tracking-[0.08em]"><span className="text-amber-500">BOM</span><span className="mx-1">💣</span><span className="text-gray-200">BULLIES</span></p>
              <p className="mt-0.5 text-[9px] uppercase tracking-[0.22em] text-gray-500">Bullies of Midgard</p>
            </div>
          </button>
          <button className="relative grid h-10 w-10 place-items-center rounded-xl border border-gray-800 bg-gray-900 text-gray-400 transition hover:border-amber-500/50 hover:text-amber-400" aria-label="Notifications"><Bell size={19} /><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-amber-500" /></button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-32 pt-5 sm:px-6 sm:pt-8">
        {activeTab === 'home' && (
          <div className="space-y-6">
            <section className="hero-card relative overflow-hidden rounded-3xl border border-amber-500/20 p-6 sm:p-9">
              <div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-amber-500/10 blur-3xl" />
              <div className="relative max-w-2xl">
                <span className="inline-flex items-center gap-2 rounded-full border border-amber-500/20 bg-amber-500/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-amber-400"><ShieldCheck size={14} />Premium American Bully Kennel</span>
                <h1 className="mt-5 text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">Built different.<br /><span className="text-amber-500">Bred with purpose.</span></h1>
                <p className="mt-4 max-w-xl text-sm leading-7 text-gray-400 sm:text-base">Explore the Bomb Bullies program, meet our dogs, follow upcoming litters, and connect directly with Bullies of Midgard.</p>
                <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                  <button onClick={() => navigate('dogs')} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-5 text-sm font-bold text-gray-950 shadow-lg shadow-amber-500/10 transition hover:from-amber-400 hover:to-amber-500">Browse Our Dogs <ArrowRight size={17} /></button>
                  <button onClick={() => navigate('connect')} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-gray-700 bg-gray-900/70 px-5 text-sm font-semibold text-gray-200 transition hover:border-amber-500/40">Contact the Kennel</button>
                </div>
              </div>
            </section>

            <section className="grid grid-cols-3 gap-3">
              {[['3','Program dogs'],['8.5–9″','Nano target'],['PNW','Home base']].map(([value,label]) => <div key={label} className="rounded-2xl border border-gray-800 bg-gray-900/70 p-4 text-center"><strong className="block text-lg font-extrabold text-amber-400 sm:text-2xl">{value}</strong><span className="mt-1 block text-[9px] uppercase tracking-[0.12em] text-gray-500 sm:text-[10px]">{label}</span></div>)}
            </section>

            <section>
              <div className="mb-4 flex items-end justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-500">The Pack</p><h2 className="mt-1 text-xl font-bold text-white sm:text-2xl">Featured Dogs</h2></div><button onClick={() => navigate('dogs')} className="flex items-center gap-1 text-xs font-semibold text-amber-400">View all <ChevronRight size={15} /></button></div>
              <div className="grid gap-4 md:grid-cols-2">
                {dogs.slice(0,2).map((dog) => <button key={dog.name} onClick={() => navigate('dogs')} className="group overflow-hidden rounded-2xl border border-gray-800 bg-gray-900 text-left transition hover:-translate-y-0.5 hover:border-amber-500/40"><div className="dog-visual relative grid h-44 place-items-center overflow-hidden"><span className="absolute left-4 top-4 rounded-full bg-gray-950/75 px-3 py-1 text-[9px] font-bold uppercase tracking-[0.12em] text-amber-400 backdrop-blur">{dog.status}</span><span className="text-6xl font-black tracking-tight text-amber-400/80 drop-shadow-2xl">{dog.monogram}</span><Heart className="absolute right-4 top-4 text-gray-400 transition group-hover:text-amber-400" size={18} /></div><div className="p-5"><h3 className="text-lg font-bold text-white">{dog.name}</h3><p className="mt-1 text-xs text-gray-500">{dog.subtitle}</p></div></button>)}
              </div>
            </section>

            <section className="rounded-2xl border border-gray-800 bg-gradient-to-r from-gray-900 to-gray-950 p-5 sm:p-6"><div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-start gap-4"><div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-amber-500/10 text-amber-400"><PawPrint size={24} /></div><div><h2 className="font-bold text-white">Upcoming Litters</h2><p className="mt-1 text-sm leading-6 text-gray-500">Pairing announcements and puppy availability will appear here.</p></div></div><button onClick={() => navigate('puppies')} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-amber-500/30 px-4 text-xs font-bold text-amber-400">View Puppy Center <ChevronRight size={16} /></button></div></section>
          </div>
        )}

        {activeTab === 'dogs' && (
          <div className="space-y-6">
            <div><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-500">Bullies of Midgard</p><h1 className="mt-2 text-3xl font-extrabold text-white">Our Dogs</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-gray-500">Meet the dogs shaping the Bomb Bullies program. Full photos, pedigrees, health testing and production records are the next content layer.</p></div>
            <label className="flex h-12 items-center gap-3 rounded-xl border border-gray-800 bg-gray-900 px-4 text-gray-500 focus-within:border-amber-500/50"><Search size={18} /><input className="w-full bg-transparent text-sm text-gray-200 outline-none" placeholder="Search the pack" aria-label="Search the pack" /></label>
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{dogs.map((dog) => <article key={dog.name} className="overflow-hidden rounded-2xl border border-gray-800 bg-gray-900"><div className="dog-visual grid h-52 place-items-center"><span className="text-7xl font-black text-amber-400/80">{dog.monogram}</span></div><div className="p-5"><span className="rounded-full bg-amber-500/10 px-3 py-1 text-[9px] font-bold uppercase tracking-[0.12em] text-amber-400">{dog.status}</span><h2 className="mt-4 text-xl font-bold text-white">{dog.name}</h2><p className="mt-1 text-xs text-gray-500">{dog.subtitle}</p><ul className="mt-4 space-y-2">{dog.details.map((detail) => <li key={detail} className="flex items-center gap-2 text-xs text-gray-400"><CheckCircle2 size={14} className="text-amber-500" />{detail}</li>)}</ul><button className="mt-5 flex w-full items-center justify-between border-t border-gray-800 pt-4 text-xs font-bold text-amber-400">View Profile <ChevronRight size={16} /></button></div></article>)}</div>
          </div>
        )}

        {activeTab === 'puppies' && (
          <div className="space-y-6">
            <div><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-500">Puppy Center</p><h1 className="mt-2 text-3xl font-extrabold text-white">Litters & Puppies</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-gray-500">A clear place for planned pairings, confirmed litters, milestones and responsible placement information.</p></div>
            <section className="rounded-3xl border border-amber-500/20 bg-gradient-to-br from-gray-900 via-gray-900 to-amber-950/20 p-6 sm:p-8"><span className="inline-flex rounded-full bg-amber-500/10 px-3 py-1 text-[9px] font-bold uppercase tracking-[0.14em] text-amber-400">Planning Stage</span><h2 className="mt-5 text-2xl font-bold text-white">The next Bomb Bullies pairing</h2><p className="mt-3 max-w-2xl text-sm leading-7 text-gray-400">Parent profiles, breeding goals, timing and application status will be published here when officially confirmed.</p><div className="mt-6 grid gap-3 sm:grid-cols-3"><div className="rounded-xl border border-gray-800 bg-gray-950/50 p-4"><Ruler size={18} className="text-amber-400" /><strong className="mt-3 block text-sm text-white">Structure goals</strong><span className="mt-1 block text-xs text-gray-500">Compact, balanced, functional.</span></div><div className="rounded-xl border border-gray-800 bg-gray-950/50 p-4"><ShieldCheck size={18} className="text-amber-400" /><strong className="mt-3 block text-sm text-white">Health records</strong><span className="mt-1 block text-xs text-gray-500">Testing shown transparently.</span></div><div className="rounded-xl border border-gray-800 bg-gray-950/50 p-4"><Heart size={18} className="text-amber-400" /><strong className="mt-3 block text-sm text-white">Right placements</strong><span className="mt-1 block text-xs text-gray-500">Homes matched with care.</span></div></div></section>
            <section className="rounded-2xl border border-dashed border-gray-700 bg-gray-900/50 p-8 text-center"><PawPrint className="mx-auto text-gray-600" size={36} /><h2 className="mt-4 font-bold text-gray-200">No puppies currently listed</h2><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-gray-500">Use the Connect tab to ask about future availability or join the interest list.</p><button onClick={() => navigate('connect')} className="mt-5 rounded-xl bg-amber-500 px-5 py-3 text-xs font-bold text-gray-950">Ask About Availability</button></section>
          </div>
        )}

        {activeTab === 'connect' && (
          <div className="grid gap-6 lg:grid-cols-[.8fr_1.2fr]">
            <section><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-500">Connect</p><h1 className="mt-2 text-3xl font-extrabold text-white">Talk with the kennel</h1><p className="mt-3 max-w-xl text-sm leading-7 text-gray-500">Ask about puppies, stud service, pedigrees or collaborations. The secure delivery system comes in the next backend phase.</p><div className="mt-6 space-y-3"><div className="flex items-center gap-4 rounded-xl border border-gray-800 bg-gray-900 p-4"><MapPin className="text-amber-400" size={20} /><div><strong className="block text-sm text-white">Pacific Northwest</strong><span className="text-xs text-gray-500">Bomb Bullies home ground</span></div></div><div className="flex items-center gap-4 rounded-xl border border-gray-800 bg-gray-900 p-4"><Mail className="text-amber-400" size={20} /><div><strong className="block text-sm text-white">Direct inquiries</strong><span className="text-xs text-gray-500">Official contact details pending review</span></div></div></div></section>
            <form onSubmit={handleSubmit} className="grid gap-4 rounded-2xl border border-gray-800 bg-gray-900 p-5 sm:grid-cols-2 sm:p-7"><label className="grid gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-gray-500">Name<input name="name" required autoComplete="name" className="h-12 rounded-xl border border-gray-700 bg-gray-950 px-4 text-sm normal-case tracking-normal text-gray-200 outline-none focus:border-amber-500" placeholder="Your name" /></label><label className="grid gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-gray-500">Email<input name="email" type="email" required autoComplete="email" className="h-12 rounded-xl border border-gray-700 bg-gray-950 px-4 text-sm normal-case tracking-normal text-gray-200 outline-none focus:border-amber-500" placeholder="you@example.com" /></label><label className="grid gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-gray-500 sm:col-span-2">Inquiry type<select name="type" className="h-12 rounded-xl border border-gray-700 bg-gray-950 px-4 text-sm normal-case tracking-normal text-gray-200 outline-none focus:border-amber-500"><option>Puppy availability</option><option>Stud service</option><option>Pedigree information</option><option>Collaboration</option></select></label><label className="grid gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-gray-500 sm:col-span-2">Message<textarea name="message" required rows={5} className="rounded-xl border border-gray-700 bg-gray-950 p-4 text-sm normal-case tracking-normal text-gray-200 outline-none focus:border-amber-500" placeholder="Tell us what you are looking for." /></label><button type="submit" className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-5 text-sm font-bold text-gray-950 sm:col-span-2">Send Inquiry <MessageCircle size={17} /></button>{confirmation && <p role="status" className="flex items-start gap-3 rounded-xl border border-green-500/20 bg-green-500/10 p-4 text-sm leading-6 text-green-400 sm:col-span-2"><CheckCircle2 size={18} className="mt-0.5 shrink-0" />{confirmation}</p>}</form>
          </div>
        )}
      </main>

      {installVisible && activeTab === 'home' && <aside className="install-banner mx-auto max-w-xl" aria-label="Install BOM Bullies"><div className="app-icon h-12 w-12 shrink-0 rounded-xl"><span className="text-2xl">B</span></div><div className="min-w-0 flex-1"><strong className="block text-sm text-gray-950">Install BOM Bullies</strong><span className="block truncate text-xs text-amber-950/70">Keep the kennel one tap away.</span></div><Download size={20} className="text-gray-950" /><button onClick={() => setInstallVisible(false)} className="grid h-8 w-8 place-items-center rounded-full bg-black/10 text-gray-950" aria-label="Dismiss install prompt"><X size={16} /></button></aside>}

      <nav className="bottom-nav" aria-label="Main app navigation"><div className="mx-auto grid max-w-xl grid-cols-4">{tabs.map((tab) => { const active = activeTab === tab.id; const icon = tab.id === 'home' ? <Home size={22} /> : tab.id === 'dogs' ? <Dog size={22} /> : tab.id === 'puppies' ? <PawPrint size={22} /> : <MessageCircle size={22} />; return <button key={tab.id} onClick={() => navigate(tab.id)} className={`bottom-nav-item ${active ? 'active' : ''}`} aria-label={`Open ${tab.label}`}>{icon}<span>{tab.label}</span></button>; })}</div></nav>
    </div>
  );
}

export default App;
